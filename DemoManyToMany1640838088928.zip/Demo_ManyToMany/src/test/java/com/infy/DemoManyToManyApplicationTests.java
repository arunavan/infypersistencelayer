package com.infy;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoManyToManyApplicationTests {

	
	void contextLoads() {
	}

}
