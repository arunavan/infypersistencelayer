package com.infy;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoSpringDataManyToOneMappingApplicationTests {

	void contextLoads() {
	}

}
