package com.infy.repository;

import java.util.List;


public interface CustomerRepository {

	public List<Object[]> getCustomerCountForCities();
	
}
