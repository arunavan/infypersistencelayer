package com.infy;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoSpringDataIdentityStrategyApplicationTests {

	
	void contextLoads() {
	}

}
