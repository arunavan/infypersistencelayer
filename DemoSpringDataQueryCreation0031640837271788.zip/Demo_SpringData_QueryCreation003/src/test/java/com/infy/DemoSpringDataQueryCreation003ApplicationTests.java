package com.infy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoSpringDataQueryCreation003ApplicationTests {

	@Test
	void contextLoads() {
	}

}
