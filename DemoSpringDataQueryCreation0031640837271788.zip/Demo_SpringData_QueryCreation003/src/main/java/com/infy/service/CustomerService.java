package com.infy.service;

public interface CustomerService {
	String findNameByEmailId(String emailId);

}
