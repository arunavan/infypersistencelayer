package com.infy.model;

public enum CustomerType {
	SILVER, GOLD, PLATINUM;
}