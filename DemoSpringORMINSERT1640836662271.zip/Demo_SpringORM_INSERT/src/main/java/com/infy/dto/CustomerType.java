package com.infy.dto;

public enum CustomerType {
	SILVER, GOLD, PLATINUM;
}
